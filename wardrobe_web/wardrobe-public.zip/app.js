const defaultItems = [
  { id: 1, name: "白衬衫", category: "上衣", color: "白色", season: "四季", location: "A区上层", note: "答辩常用，搭配深灰西裤" },
  { id: 2, name: "深灰西裤", category: "下装", color: "灰色", season: "四季", location: "A区下层", note: "与白衬衫成套收纳" },
  { id: 3, name: "浅蓝牛仔外套", category: "外套", color: "蓝色", season: "春秋", location: "B区中层", note: "通勤常穿，靠近照明区" },
  { id: 4, name: "黑色卫衣", category: "上衣", color: "黑色", season: "秋冬", location: "B区下层", note: "日常穿着，取用频率高" },
  { id: 5, name: "米色针织开衫", category: "外套", color: "米色", season: "春秋", location: "C区上层", note: "轻薄备用，适合空调房" }
];

const modeLabels = { 0: "手动", 1: "智能", 2: "定时" };
const binaryLabels = { 0: "关闭", 1: "开启" };
const VENT_ON_THRESHOLD = 0;
const VENT_OFF_THRESHOLD = 101;

const ONENET = {
  productId: "PU3721W9C4",
  deviceName: "stm32",
  deviceId: "2592570552",
  statusUrl: "https://iot-api.heclouds.com/datapoint/current-datapoints",
  commandUrl: "https://api.heclouds.com/v1/synccmds",
  statusAuth: {
    accessKey: "azlraXdmMlBsVkRxcTRTNHR4OFZWRGJ1dmhqUURuV3o=",
    resource: "products/PU3721W9C4/devices/stm32",
    version: "2018-10-31",
    method: "sha1",
    ttlSeconds: 3600
  },
  commandAuth: {
    accessKey: "f2XN78l/az93zz+HUwH1J30V529HwR+vh50bTVXB2x0=",
    resource: "products/PU3721W9C4",
    version: "2018-10-31",
    method: "sha1",
    ttlSeconds: 3600
  }
};

const stateEls = {
  temp: document.getElementById("temp-value"),
  humi: document.getElementById("humi-value"),
  tvoc: document.getElementById("tvoc-value"),
  pm25: document.getElementById("pm25-value"),
  mode: document.getElementById("mode-text"),
  fan: document.getElementById("fan-text"),
  ster: document.getElementById("sterilize-text"),
  door: document.getElementById("door-text"),
  humiThreshold: document.getElementById("h-threshold"),
  pmThreshold: document.getElementById("pm-threshold"),
  lastUpdate: document.getElementById("last-update"),
  bridgeStatus: document.getElementById("bridge-status"),
  commandLog: document.getElementById("command-log")
};

let items = loadItems();
let selectedCategory = "全部";
let selectedSeason = "全部";
let selectedLocation = "全部";
let selectedItemId = null;
let recentIds = loadRecentIds();
let polling = false;
let pollTimer = null;
let currentState = {};

function loadItems() {
  const saved = localStorage.getItem("wardrobe-items");
  if (!saved) return defaultItems;
  try {
    return JSON.parse(saved);
  } catch {
    return defaultItems;
  }
}

function loadRecentIds() {
  try {
    const saved = JSON.parse(localStorage.getItem("wardrobe-recent-ids") || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveRecentIds() {
  localStorage.setItem("wardrobe-recent-ids", JSON.stringify(recentIds.slice(0, 5)));
}

function categories() {
  return ["全部", ...new Set(items.map((item) => item.category))];
}

function seasons() {
  return ["全部", ...new Set(items.map((item) => item.season))];
}

function locations() {
  return ["全部", ...new Set(items.map((item) => item.location))];
}

function fillSelect(selectId, values, selectedValue) {
  const select = document.getElementById(selectId);
  select.innerHTML = "";
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    option.selected = value === selectedValue;
    select.appendChild(option);
  });
}

function renderCategoryChips() {
  const root = document.getElementById("category-chips");
  root.innerHTML = "";
  categories().forEach((category) => {
    const btn = document.createElement("button");
    btn.className = `chip${selectedCategory === category ? " active" : ""}`;
    btn.textContent = category;
    btn.onclick = () => {
      selectedCategory = category;
      renderCategoryChips();
      renderItems();
    };
    root.appendChild(btn);
  });
}

function renderFilterSelects() {
  fillSelect("season-filter", seasons(), selectedSeason);
  fillSelect("location-filter", locations(), selectedLocation);
}

function renderRecentChips() {
  const root = document.getElementById("recent-chips");
  root.innerHTML = "";
  const recentItems = recentIds.map((id) => items.find((item) => item.id === id)).filter(Boolean);

  if (!recentItems.length) {
    const placeholder = document.createElement("span");
    placeholder.className = "empty-hint";
    placeholder.textContent = "还没有最近查找记录";
    root.appendChild(placeholder);
    return;
  }

  recentItems.forEach((item) => {
    const btn = document.createElement("button");
    btn.className = "chip";
    btn.textContent = item.name;
    btn.onclick = () => selectItem(item.id);
    root.appendChild(btn);
  });
}

function filteredItems() {
  const query = document.getElementById("search-input").value.trim().toLowerCase();
  return items.filter((item) => {
    const categoryOk = selectedCategory === "全部" || item.category === selectedCategory;
    const seasonOk = selectedSeason === "全部" || item.season === selectedSeason;
    const locationOk = selectedLocation === "全部" || item.location === selectedLocation;
    const queryOk = !query || [item.name, item.color, item.location, item.note].join(" ").toLowerCase().includes(query);
    return categoryOk && seasonOk && locationOk && queryOk;
  });
}

function renderItems() {
  const list = document.getElementById("item-list");
  const rows = filteredItems();
  document.getElementById("finder-count").textContent = `${rows.length} 件`;
  list.innerHTML = "";

  rows.forEach((item) => {
    const card = document.createElement("article");
    card.className = `item-card${item.id === selectedItemId ? " selected" : ""}`;
    card.innerHTML = `
      <div class="item-name">${item.name}</div>
      <div class="item-meta">${item.category} / ${item.color} / ${item.season}<br>${item.location} / ${item.note}</div>
    `;
    card.onclick = () => selectItem(item.id);
    list.appendChild(card);
  });

  if (!rows.length) {
    list.innerHTML = `
      <article class="item-card">
        <div class="item-name">没有找到匹配衣物</div>
        <div class="item-meta">可以换一个关键词，或者调整季节、区域筛选。</div>
      </article>
    `;
  }
}

function rememberRecent(id) {
  recentIds = [id, ...recentIds.filter((itemId) => itemId !== id)].slice(0, 5);
  saveRecentIds();
  renderRecentChips();
}

function selectItem(id) {
  selectedItemId = id;
  renderItems();
  const item = items.find((entry) => entry.id === id);
  if (!item) return;

  rememberRecent(id);
  document.getElementById("location-name").textContent = `${item.name} / ${item.location}`;
  document.getElementById("location-meta").textContent = `${item.category} / ${item.color} / ${item.season} / ${item.note}`;
  document.getElementById("finder-door-btn").disabled = false;
  document.getElementById("finder-copy-btn").disabled = false;
}

function utf8ToBytes(str) {
  return Array.from(new TextEncoder().encode(str));
}

function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = [];
  for (let i = 0; i < binary.length; i += 1) {
    bytes.push(binary.charCodeAt(i));
  }
  return bytes;
}

function bytesToBase64(bytes) {
  return btoa(String.fromCharCode(...bytes));
}

function rotl(value, bits) {
  return (value << bits) | (value >>> (32 - bits));
}

function sha1(bytes) {
  const words = [];
  for (let i = 0; i < bytes.length; i += 1) {
    words[i >>> 2] = (words[i >>> 2] || 0) | (bytes[i] << (24 - (i % 4) * 8));
  }
  words[bytes.length >>> 2] = (words[bytes.length >>> 2] || 0) | (0x80 << (24 - (bytes.length % 4) * 8));
  words[(((bytes.length + 8) >>> 6) << 4) + 15] = bytes.length * 8;

  const w = new Array(80);
  let h0 = 0x67452301;
  let h1 = 0xefcdab89;
  let h2 = 0x98badcfe;
  let h3 = 0x10325476;
  let h4 = 0xc3d2e1f0;

  for (let blockStart = 0; blockStart < words.length; blockStart += 16) {
    const oldH0 = h0;
    const oldH1 = h1;
    const oldH2 = h2;
    const oldH3 = h3;
    const oldH4 = h4;

    for (let i = 0; i < 80; i += 1) {
      if (i < 16) {
        w[i] = words[blockStart + i] || 0;
      } else {
        w[i] = rotl(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
      }

      let f;
      let k;
      if (i < 20) {
        f = (h1 & h2) | (~h1 & h3);
        k = 0x5a827999;
      } else if (i < 40) {
        f = h1 ^ h2 ^ h3;
        k = 0x6ed9eba1;
      } else if (i < 60) {
        f = (h1 & h2) | (h1 & h3) | (h2 & h3);
        k = 0x8f1bbcdc;
      } else {
        f = h1 ^ h2 ^ h3;
        k = 0xca62c1d6;
      }

      const temp = (rotl(h0, 5) + f + h4 + k + w[i]) | 0;
      h4 = h3;
      h3 = h2;
      h2 = rotl(h1, 30);
      h1 = h0;
      h0 = temp;
    }

    h0 = (h0 + oldH0) | 0;
    h1 = (h1 + oldH1) | 0;
    h2 = (h2 + oldH2) | 0;
    h3 = (h3 + oldH3) | 0;
    h4 = (h4 + oldH4) | 0;
  }

  return [
    (h0 >>> 24) & 0xff, (h0 >>> 16) & 0xff, (h0 >>> 8) & 0xff, h0 & 0xff,
    (h1 >>> 24) & 0xff, (h1 >>> 16) & 0xff, (h1 >>> 8) & 0xff, h1 & 0xff,
    (h2 >>> 24) & 0xff, (h2 >>> 16) & 0xff, (h2 >>> 8) & 0xff, h2 & 0xff,
    (h3 >>> 24) & 0xff, (h3 >>> 16) & 0xff, (h3 >>> 8) & 0xff, h3 & 0xff,
    (h4 >>> 24) & 0xff, (h4 >>> 16) & 0xff, (h4 >>> 8) & 0xff, h4 & 0xff
  ];
}

function hmacSha1(keyBytes, messageBytes) {
  let normalizedKey = keyBytes.slice();
  if (normalizedKey.length > 64) {
    normalizedKey = sha1(normalizedKey);
  }

  const oKeyPad = new Array(64).fill(0);
  const iKeyPad = new Array(64).fill(0);
  for (let i = 0; i < 64; i += 1) {
    const value = normalizedKey[i] || 0;
    oKeyPad[i] = value ^ 0x5c;
    iKeyPad[i] = value ^ 0x36;
  }

  const inner = sha1(iKeyPad.concat(messageBytes));
  return sha1(oKeyPad.concat(inner));
}

function buildToken({ accessKey, resource, version, method, ttlSeconds }) {
  const expires = Math.floor(Date.now() / 1000) + ttlSeconds;
  const signInput = `${expires}\n${method}\n${resource}\n${version}`;
  const signBytes = hmacSha1(base64ToBytes(accessKey), utf8ToBytes(signInput));
  const sign = encodeURIComponent(bytesToBase64(signBytes));
  return `version=${version}&res=${encodeURIComponent(resource)}&et=${expires}&method=${method}&sign=${sign}`;
}

function mapStateFromDatastreams(datastreams = []) {
  const streamMap = {};
  datastreams.forEach((stream) => {
    streamMap[stream.id] = stream.value;
  });
  return {
    temp_c: streamMap.temp,
    humi: streamMap.humi,
    tvoc_mg: streamMap.tvoc,
    pm25_mg: streamMap.pm25,
    mode: streamMap.mode,
    R1: streamMap.r1,
    R2: streamMap.r2,
    SG: streamMap.sg,
    humidity_threshold: streamMap.h_y,
    pm_threshold: streamMap.p_y,
    received_at: datastreams[0] ? datastreams[0].at : "--"
  };
}

function applyState(state) {
  currentState = { ...currentState, ...state };
  stateEls.temp.textContent = state.temp_c ?? "--";
  stateEls.humi.textContent = state.humi ?? "--";
  stateEls.tvoc.textContent = state.tvoc_mg ?? "--";
  stateEls.pm25.textContent = state.pm25_mg ?? "--";
  stateEls.mode.textContent = modeLabels[state.mode] ?? "--";
  stateEls.fan.textContent = binaryLabels[state.R2] ?? "--";
  stateEls.ster.textContent = binaryLabels[state.R1] ?? "--";
  stateEls.door.textContent = state.SG === 1 ? "打开" : state.SG === 0 ? "关闭" : "--";
  stateEls.humiThreshold.textContent = state.humidity_threshold ?? "--";
  stateEls.pmThreshold.textContent = state.pm_threshold ?? "--";
  stateEls.lastUpdate.textContent = state.received_at || "等待平台数据";

  document.querySelectorAll(".seg-btn").forEach((btn) => btn.classList.remove("active"));
  if (state.mode !== undefined && state.mode !== null) {
    const active = document.querySelector(`.seg-btn[data-mode="${state.mode}"]`);
    if (active) active.classList.add("active");
  }

  if (state.humidity_threshold !== undefined && state.humidity_threshold !== null) {
    document.getElementById("humidity-input").value = state.humidity_threshold;
  }
  if (state.pm_threshold !== undefined && state.pm_threshold !== null) {
    document.getElementById("pm-input").value = state.pm_threshold;
  }
}

function applyOptimisticState(command) {
  const nextState = { ...currentState };

  if (command.mode !== undefined) nextState.mode = Number(command.mode);
  if (command.SG !== undefined) nextState.SG = Number(command.SG);
  if (command.R1 !== undefined) nextState.R1 = Number(command.R1);
  if (command.Hu !== undefined) {
    nextState.humidity_threshold = Number(command.Hu);
    if (Number(command.Hu) <= VENT_ON_THRESHOLD) nextState.R2 = 1;
    if (Number(command.Hu) >= VENT_OFF_THRESHOLD) nextState.R2 = 0;
  }
  if (command.PM !== undefined) nextState.pm_threshold = Number(command.PM);

  applyState(nextState);
}

function setBridgeConnected(connected, text) {
  stateEls.bridgeStatus.innerHTML = `
    <span class="status-dot ${connected ? "status-online" : "status-offline"}"></span>
    <span>${text}</span>
  `;
}

async function fetchOneNETStatus() {
  const url = `${ONENET.statusUrl}?product_id=${encodeURIComponent(ONENET.productId)}&device_name=${encodeURIComponent(ONENET.deviceName)}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: buildToken(ONENET.statusAuth),
      Accept: "application/json, text/plain, */*"
    }
  });
  const payload = await response.json();
  if (payload.code !== 0) {
    throw new Error(payload.msg || "OneNET 状态读取失败");
  }
  return mapStateFromDatastreams((((payload || {}).data || {}).devices || [])[0]?.datastreams || []);
}

async function sendOneNETCommand(command) {
  const url = `${ONENET.commandUrl}?device_id=${encodeURIComponent(ONENET.deviceId)}&timeout=6`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: buildToken(ONENET.commandAuth),
      Accept: "application/json, text/plain, */*"
    },
    body: JSON.stringify(command)
  });
  const payload = await response.json();
  if (Number(payload.errno) !== 0) {
    throw new Error(payload.error || "命令发送失败");
  }
  return payload;
}

async function postCommand(command, successText) {
  stateEls.commandLog.textContent = "命令发送中...";
  try {
    const result = await sendOneNETCommand(command);
    applyOptimisticState(command);
    stateEls.commandLog.textContent = result?.data?.cmd_resp ? "命令已送达设备" : `${successText}，等待设备状态刷新...`;
    window.setTimeout(() => {
      pollStatus(true);
    }, 1200);
  } catch (error) {
    stateEls.commandLog.textContent = `命令发送失败：${error.message}`;
  }
}

async function pollStatus(force = false) {
  if (polling && !force) return;
  polling = true;

  try {
    const state = await fetchOneNETStatus();
    setBridgeConnected(true, "OneNET 已连接");
    applyState(state);
  } catch (error) {
    setBridgeConnected(false, "OneNET 未连接");
    stateEls.commandLog.textContent = `状态读取失败：${error.message}`;
  } finally {
    polling = false;
    window.clearTimeout(pollTimer);
    pollTimer = window.setTimeout(() => pollStatus(false), 6000);
  }
}

async function copyLocationInfo() {
  const name = document.getElementById("location-name").textContent;
  const meta = document.getElementById("location-meta").textContent;
  const text = `${name}\n${meta}`;
  try {
    await navigator.clipboard.writeText(text);
    stateEls.commandLog.textContent = "已复制当前位置说明";
  } catch (error) {
    stateEls.commandLog.textContent = `复制失败：${error.message}`;
  }
}

document.getElementById("search-input").addEventListener("input", renderItems);
document.getElementById("season-filter").addEventListener("change", (event) => {
  selectedSeason = event.target.value;
  renderItems();
});
document.getElementById("location-filter").addEventListener("change", (event) => {
  selectedLocation = event.target.value;
  renderItems();
});

document.getElementById("finder-door-btn").onclick = () => postCommand({ SG: 1 }, "已发送查找提示开柜门");
document.getElementById("finder-copy-btn").onclick = copyLocationInfo;
document.getElementById("door-open-btn").onclick = () => postCommand({ SG: 1 }, "已发送开柜门");
document.getElementById("door-close-btn").onclick = () => postCommand({ SG: 0 }, "已发送关柜门");
document.getElementById("ster-on-btn").onclick = () => postCommand({ mode: 0, R1: 1 }, "已发送手动消毒开");
document.getElementById("ster-off-btn").onclick = () => postCommand({ mode: 0, R1: 0 }, "已发送手动消毒关");
document.getElementById("vent-on-btn").onclick = () => postCommand({ Hu: VENT_ON_THRESHOLD }, "已发送通风开启");
document.getElementById("vent-off-btn").onclick = () => postCommand({ Hu: VENT_OFF_THRESHOLD }, "已发送通风关闭");

document.querySelectorAll(".seg-btn").forEach((btn) => {
  btn.onclick = () => postCommand({ mode: Number(btn.dataset.mode) }, `已发送模式切换到 ${btn.textContent}`);
});

document.getElementById("send-settings-btn").onclick = () => {
  const humidity = Number(document.getElementById("humidity-input").value);
  const pm = Number(document.getElementById("pm-input").value);
  const start = document.getElementById("start-input").value;
  const end = document.getElementById("end-input").value;
  postCommand({ Hu: humidity, PM: pm, ST: start, ET: end }, "已发送阈值与定时设置");
};

renderCategoryChips();
renderFilterSelects();
renderRecentChips();
renderItems();
pollStatus(true);
