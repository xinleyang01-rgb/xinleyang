const ONENET = {
  productId: "PU3721W9C4",
  deviceName: "stm32",
  deviceId: "2592570552",
  statusUrl: "https://iot-api.heclouds.com/datapoint/current-datapoints",
  commandUrl: "https://api.heclouds.com/v1/synccmds",
  statusAuth: {
    accessKey: "azlraXdmMlBsVkRxcTRTNHR4OFZWRGJ1dmhqUURuV3o=",
    resource: "products/PU3721W9C4/devices/stm32",
    version: "2018-10-31",
    method: "sha1",
    ttlSeconds: 3600
  },
  commandAuth: {
    accessKey: "f2XN78l/az93zz+HUwH1J30V529HwR+vh50bTVXB2x0=",
    resource: "products/PU3721W9C4",
    version: "2018-10-31",
    method: "sha1",
    ttlSeconds: 3600
  }
};

const ITEMS = [
  { id: 1, name: "白衬衫", category: "上衣", color: "白色", season: "四季", location: "A区上层", note: "答辩常用，搭配深灰西裤" },
  { id: 2, name: "深灰西裤", category: "下装", color: "灰色", season: "四季", location: "A区下层", note: "与白衬衫成套收纳" },
  { id: 3, name: "浅蓝牛仔外套", category: "外套", color: "蓝色", season: "春秋", location: "B区中层", note: "通勤常穿，靠近照明区" },
  { id: 4, name: "黑色卫衣", category: "上衣", color: "黑色", season: "秋冬", location: "B区下层", note: "日常穿着，取用频率高" },
  { id: 5, name: "米色针织开衫", category: "外套", color: "米色", season: "春秋", location: "C区上层", note: "轻薄备用，适合空调房" }
];

const MODE_LABELS = { 0: "手动", 1: "智能", 2: "定时" };
const SWITCH_LABELS = { 0: "关闭", 1: "开启" };
const VENT_ON_THRESHOLD = 0;
const VENT_OFF_THRESHOLD = 101;

const uiState = {
  current: {},
  selectedCategory: "全部",
  selectedSeason: "全部",
  selectedLocation: "全部",
  selectedItemId: null,
  recentIds: [],
  polling: false,
  pollTimer: null,
  commandSettlingUntil: 0
};

const els = {};

function $(id) {
  return document.getElementById(id);
}

function categories() {
  return ["全部", ...new Set(ITEMS.map((item) => item.category))];
}

function seasons() {
  return ["全部", ...new Set(ITEMS.map((item) => item.season))];
}

function locations() {
  return ["全部", ...new Set(ITEMS.map((item) => item.location))];
}

function filteredItems() {
  const keyword = (els.searchInput.value || "").trim().toLowerCase();
  return ITEMS.filter((item) => {
    const matchKeyword = !keyword || `${item.name} ${item.color} ${item.location} ${item.note}`.toLowerCase().includes(keyword);
    const matchCategory = uiState.selectedCategory === "全部" || item.category === uiState.selectedCategory;
    const matchSeason = uiState.selectedSeason === "全部" || item.season === uiState.selectedSeason;
    const matchLocation = uiState.selectedLocation === "全部" || item.location === uiState.selectedLocation;
    return matchKeyword && matchCategory && matchSeason && matchLocation;
  });
}

function persistRecent() {
  localStorage.setItem("wardrobe-recent-ids", JSON.stringify(uiState.recentIds.slice(0, 5)));
}

function fillSelect(select, values, selected) {
  select.innerHTML = "";
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    option.selected = value === selected;
    select.appendChild(option);
  });
}

function renderBridgeStatus(kind, text) {
  els.bridgeStatus.className = `bridge-status ${kind}`;
  els.bridgeStatusText.textContent = text;
}

function setMetric(el, value) {
  el.textContent = value === undefined || value === null || value === "" ? "--" : String(value);
}

function renderModeButtons() {
  document.querySelectorAll(".seg-btn").forEach((btn) => {
    btn.classList.toggle("active", Number(btn.dataset.mode) === Number(uiState.current.mode));
  });
}

function renderCurrentItem(item) {
  els.locationName.textContent = item ? item.name : "未选择衣物";
  els.locationMeta.textContent = item ? `${item.category} / ${item.color} / ${item.season} / ${item.location}\n${item.note}` : "选中衣物后，会显示推荐位置、搭配说明，并支持一键开柜门辅助查找。";
  els.finderDoorBtn.disabled = !item;
  els.finderCopyBtn.disabled = !item;
}

function selectItem(itemId) {
  uiState.selectedItemId = itemId;
  const item = ITEMS.find((entry) => entry.id === itemId) || null;
  if (item) {
    uiState.recentIds = [item.id, ...uiState.recentIds.filter((id) => id !== item.id)].slice(0, 5);
    persistRecent();
  }
  renderCurrentItem(item);
  renderRecentChips();
  renderItems();
}

function renderRecentChips() {
  els.recentChips.innerHTML = "";
  const recentItems = uiState.recentIds
    .map((id) => ITEMS.find((item) => item.id === id))
    .filter(Boolean);

  if (!recentItems.length) {
    const placeholder = document.createElement("span");
    placeholder.className = "empty-hint";
    placeholder.textContent = "还没有最近查找记录";
    els.recentChips.appendChild(placeholder);
    return;
  }

  recentItems.forEach((item) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "chip";
    btn.textContent = item.name;
    btn.onclick = () => selectItem(item.id);
    els.recentChips.appendChild(btn);
  });
}

function renderItems() {
  const rows = filteredItems();
  els.finderCount.textContent = `${rows.length} 件`;
  els.itemList.innerHTML = "";

  rows.forEach((item) => {
    const card = document.createElement("article");
    card.className = `item-card${item.id === uiState.selectedItemId ? " selected" : ""}`;
    card.innerHTML = `
      <div class="item-name">${item.name}</div>
      <div class="item-meta">${item.category} / ${item.color} / ${item.season}<br>${item.location} / ${item.note}</div>
    `;
    card.onclick = () => selectItem(item.id);
    els.itemList.appendChild(card);
  });

  if (!rows.length) {
    const empty = document.createElement("article");
    empty.className = "item-card";
    empty.innerHTML = `
      <div class="item-name">没有找到匹配衣物</div>
      <div class="item-meta">可以换一个关键词，或者调整季节、区域筛选。</div>
    `;
    els.itemList.appendChild(empty);
  }

  if (rows.length && !rows.some((item) => item.id === uiState.selectedItemId)) {
    selectItem(rows[0].id);
  } else if (!rows.length) {
    uiState.selectedItemId = null;
    renderCurrentItem(null);
  }
}

function renderCategoryChips() {
  els.categoryChips.innerHTML = "";
  categories().forEach((category) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `chip${uiState.selectedCategory === category ? " active" : ""}`;
    btn.textContent = category;
    btn.onclick = () => {
      uiState.selectedCategory = category;
      renderCategoryChips();
      renderItems();
    };
    els.categoryChips.appendChild(btn);
  });
}

function renderFilterSelects() {
  fillSelect(els.seasonFilter, seasons(), uiState.selectedSeason);
  fillSelect(els.locationFilter, locations(), uiState.selectedLocation);
}

function applyState(state) {
  uiState.current = state;
  setMetric(els.tempValue, state.temp);
  setMetric(els.humiValue, state.humi);
  setMetric(els.tvocValue, state.tvoc);
  setMetric(els.pm25Value, state.pm25);
  els.modeText.textContent = MODE_LABELS[state.mode] ?? "--";
  els.fanText.textContent = SWITCH_LABELS[state.r2] ?? "--";
  els.sterilizeText.textContent = SWITCH_LABELS[state.r1] ?? "--";
  els.doorText.textContent = state.sg === 1 ? "打开" : state.sg === 0 ? "关闭" : "--";
  setMetric(els.hThreshold, state.h_y);
  setMetric(els.pmThreshold, state.p_y);
  els.lastUpdate.textContent = state.at || "等待平台数据";
  els.humidityInput.value = state.h_y ?? els.humidityInput.value;
  els.pmInput.value = state.p_y ?? els.pmInput.value;
  renderModeButtons();
}

function normalizeState(payload) {
  const device = (((payload || {}).data || {}).devices || [])[0] || {};
  const streams = device.datastreams || [];
  const streamMap = {};
  streams.forEach((stream) => {
    streamMap[stream.id] = stream.value;
  });

  return {
    temp: streamMap.temp ?? "--",
    humi: streamMap.humi ?? "--",
    tvoc: streamMap.tvoc ?? "--",
    pm25: streamMap.pm25 ?? "--",
    mode: Number(streamMap.mode ?? 0),
    h_y: streamMap.h_y ?? "--",
    p_y: streamMap.p_y ?? "--",
    r1: Number(streamMap.r1 ?? 0),
    r2: Number(streamMap.r2 ?? 0),
    sg: Number(streamMap.sg ?? 0),
    at: streams[0] ? streams[0].at : "--"
  };
}

async function buildToken(authConfig) {
  if (!window.crypto || !window.crypto.subtle) {
    throw new Error("当前浏览器不支持 Web Crypto，无法生成 OneNET 鉴权");
  }

  const expires = Math.floor(Date.now() / 1000) + Number(authConfig.ttlSeconds || 3600);
  const signInput = `${expires}\n${authConfig.method}\n${authConfig.resource}\n${authConfig.version}`;
  const keyBytes = Uint8Array.from(atob(authConfig.accessKey), (ch) => ch.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(signInput));
  const base64Sign = btoa(String.fromCharCode(...new Uint8Array(signature)));
  return `version=${authConfig.version}&res=${encodeURIComponent(authConfig.resource)}&et=${expires}&method=${authConfig.method}&sign=${encodeURIComponent(base64Sign)}`;
}

async function fetchOneNETStatus() {
  const authorization = await buildToken(ONENET.statusAuth);
  const url = `${ONENET.statusUrl}?product_id=${encodeURIComponent(ONENET.productId)}&device_name=${encodeURIComponent(ONENET.deviceName)}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json, text/plain, */*",
      Authorization: authorization
    }
  });
  const payload = await response.json();
  if (payload.code !== 0) {
    throw new Error(payload.msg || "OneNET 状态读取失败");
  }
  return normalizeState(payload);
}

function isNumericEqual(left, right) {
  return Number(left) === Number(right);
}

function commandMatchesState(command, state) {
  if (Object.prototype.hasOwnProperty.call(command, "mode") && !isNumericEqual(state.mode, command.mode)) {
    return false;
  }
  if (Object.prototype.hasOwnProperty.call(command, "SG") && !isNumericEqual(state.sg, command.SG)) {
    return false;
  }
  if (Object.prototype.hasOwnProperty.call(command, "R1") && !isNumericEqual(state.r1, command.R1)) {
    return false;
  }
  if (Object.prototype.hasOwnProperty.call(command, "R2") && !isNumericEqual(state.r2, command.R2)) {
    return false;
  }
  if (Object.prototype.hasOwnProperty.call(command, "Hu")) {
    if (!isNumericEqual(state.h_y, command.Hu)) return false;
    if (Number(command.Hu) <= 0 && !isNumericEqual(state.r2, 1)) return false;
    if (Number(command.Hu) >= 101 && !isNumericEqual(state.r2, 0)) return false;
  }
  if (Object.prototype.hasOwnProperty.call(command, "PM") && !isNumericEqual(state.p_y, command.PM)) {
    return false;
  }
  return true;
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function waitForCommandReflection(command, timeoutMs = 10000, intervalMs = 1500) {
  const deadline = Date.now() + timeoutMs;
  let lastState = null;
  let lastError = null;

  while (Date.now() < deadline) {
    try {
      const state = await fetchOneNETStatus();
      lastState = state;
      applyState(state);
      renderBridgeStatus("connected", "OneNET 已连接");
      if (commandMatchesState(command, state)) {
        return { matched: true, state };
      }
    } catch (error) {
      lastError = error;
    }
    await sleep(intervalMs);
  }

  if (lastError) {
    throw lastError;
  }
  return { matched: false, state: lastState };
}

function applyOptimisticState(command) {
  const next = { ...uiState.current };
  if (Object.prototype.hasOwnProperty.call(command, "mode")) next.mode = Number(command.mode);
  if (Object.prototype.hasOwnProperty.call(command, "R1")) next.r1 = Number(command.R1);
  if (Object.prototype.hasOwnProperty.call(command, "R2")) next.r2 = Number(command.R2);
  if (Object.prototype.hasOwnProperty.call(command, "SG")) next.sg = Number(command.SG);
  if (Object.prototype.hasOwnProperty.call(command, "Hu")) {
    next.h_y = Number(command.Hu);
    if (Number(command.Hu) <= 0) next.r2 = 1;
    if (Number(command.Hu) >= 101) next.r2 = 0;
  }
  if (Object.prototype.hasOwnProperty.call(command, "PM")) next.p_y = Number(command.PM);
  applyState(next);
}

async function postCommand(command, successText) {
  els.commandLog.textContent = `${successText}，正在发送到 OneNET...`;
  applyOptimisticState(command);
  window.clearTimeout(uiState.pollTimer);

  try {
    const authorization = await buildToken(ONENET.commandAuth);
    const url = `${ONENET.commandUrl}?device_id=${encodeURIComponent(ONENET.deviceId)}&timeout=6`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/plain, */*",
        Authorization: authorization
      },
      body: JSON.stringify(command)
    });
    const payload = await response.json();
    const errno = String(payload.errno ?? "");
    if (!(errno === "0" || errno === "000000")) {
      throw new Error(payload.error || "命令发送失败");
    }
    uiState.commandSettlingUntil = Date.now() + 10000;
    els.commandLog.textContent = "命令已送达设备，正在等待设备上报匹配状态...";
    const result = await waitForCommandReflection(command);
    if (result.matched) {
      els.commandLog.textContent = "设备已上报新状态";
    } else {
      els.commandLog.textContent = "平台已接收命令，但设备未在预期时间内上报匹配状态";
    }
  } catch (error) {
    const message = error.message || "命令发送失败";
    if (/timeout/i.test(message)) {
      els.commandLog.textContent = "平台等待回执超时，继续检查设备状态...";
      try {
        uiState.commandSettlingUntil = Date.now() + 10000;
        const result = await waitForCommandReflection(command);
        if (result.matched) {
          els.commandLog.textContent = "设备虽未及时回执，但已上报新状态";
        } else {
          els.commandLog.textContent = "平台回执超时，且设备未上报匹配状态";
        }
      } catch (verifyError) {
        els.commandLog.textContent = `命令发送失败：${verifyError.message}`;
      }
    } else {
      els.commandLog.textContent = `命令发送失败：${message}`;
    }
  } finally {
    uiState.commandSettlingUntil = 0;
    scheduleNextPoll();
  }
}

function scheduleNextPoll() {
  window.clearTimeout(uiState.pollTimer);
  const waitMs = Math.max(6000, uiState.commandSettlingUntil - Date.now(), 0);
  uiState.pollTimer = window.setTimeout(() => pollStatus(false), waitMs);
}

async function pollStatus(immediate) {
  if (!immediate && Date.now() < uiState.commandSettlingUntil) {
    scheduleNextPoll();
    return;
  }
  if (uiState.polling) return;
  uiState.polling = true;
  if (immediate) renderBridgeStatus("pending", "OneNET 状态刷新中");

  try {
    const state = await fetchOneNETStatus();
    applyState(state);
    renderBridgeStatus("connected", "OneNET 已连接");
  } catch (error) {
    renderBridgeStatus("error", "OneNET 状态读取失败");
    els.commandLog.textContent = `状态读取失败：${error.message}`;
  } finally {
    uiState.polling = false;
    scheduleNextPoll();
  }
}

async function copyLocationInfo() {
  const item = ITEMS.find((entry) => entry.id === uiState.selectedItemId);
  if (!item) return;
  const text = `${item.name}\n${item.category} / ${item.color} / ${item.season}\n${item.location}\n${item.note}`;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      textarea.remove();
    }
    els.commandLog.textContent = "已复制位置说明";
  } catch (error) {
    els.commandLog.textContent = `复制失败：${error.message}`;
  }
}

function bindEvents() {
  els.searchInput.addEventListener("input", renderItems);
  els.seasonFilter.addEventListener("change", (event) => {
    uiState.selectedSeason = event.target.value;
    renderItems();
  });
  els.locationFilter.addEventListener("change", (event) => {
    uiState.selectedLocation = event.target.value;
    renderItems();
  });

  els.finderDoorBtn.onclick = () => postCommand({ SG: 1 }, "已发送查找提示开柜门");
  els.finderCopyBtn.onclick = copyLocationInfo;
  els.doorOpenBtn.onclick = () => postCommand({ SG: 1 }, "已发送开柜门");
  els.doorCloseBtn.onclick = () => postCommand({ SG: 0 }, "已发送关柜门");
  els.sterOnBtn.onclick = () => postCommand({ mode: 0, R1: 1 }, "已发送手动消毒开");
  els.sterOffBtn.onclick = () => postCommand({ mode: 0, R1: 0 }, "已发送手动消毒关");
  els.ventOnBtn.onclick = () => postCommand({ Hu: VENT_ON_THRESHOLD }, "已发送通风开");
  els.ventOffBtn.onclick = () => postCommand({ Hu: VENT_OFF_THRESHOLD }, "已发送通风关");
  els.sendSettingsBtn.onclick = () => {
    const humidity = Number(els.humidityInput.value);
    const pm = Number(els.pmInput.value);
    const start = els.startInput.value;
    const end = els.endInput.value;
    postCommand({ Hu: humidity, PM: pm, ST: start, ET: end }, "已发送阈值与定时设置");
  };

  document.querySelectorAll(".seg-btn").forEach((btn) => {
    btn.onclick = () => {
      postCommand({ mode: Number(btn.dataset.mode) }, `已发送模式切换到 ${btn.textContent}`);
    };
  });
}

function initDomRefs() {
  els.searchInput = $("search-input");
  els.categoryChips = $("category-chips");
  els.seasonFilter = $("season-filter");
  els.locationFilter = $("location-filter");
  els.recentChips = $("recent-chips");
  els.itemList = $("item-list");
  els.finderCount = $("finder-count");
  els.locationName = $("location-name");
  els.locationMeta = $("location-meta");
  els.finderDoorBtn = $("finder-door-btn");
  els.finderCopyBtn = $("finder-copy-btn");
  els.tempValue = $("temp-value");
  els.humiValue = $("humi-value");
  els.tvocValue = $("tvoc-value");
  els.pm25Value = $("pm25-value");
  els.modeText = $("mode-text");
  els.fanText = $("fan-text");
  els.sterilizeText = $("sterilize-text");
  els.doorText = $("door-text");
  els.hThreshold = $("h-threshold");
  els.pmThreshold = $("pm-threshold");
  els.lastUpdate = $("last-update");
  els.bridgeStatus = $("bridge-status");
  els.bridgeStatusText = $("bridge-status-text");
  els.commandLog = $("command-log");
  els.doorOpenBtn = $("door-open-btn");
  els.doorCloseBtn = $("door-close-btn");
  els.sterOnBtn = $("ster-on-btn");
  els.sterOffBtn = $("ster-off-btn");
  els.ventOnBtn = $("vent-on-btn");
  els.ventOffBtn = $("vent-off-btn");
  els.humidityInput = $("humidity-input");
  els.pmInput = $("pm-input");
  els.startInput = $("start-input");
  els.endInput = $("end-input");
  els.sendSettingsBtn = $("send-settings-btn");
}

function init() {
  initDomRefs();
  try {
    const saved = JSON.parse(localStorage.getItem("wardrobe-recent-ids") || "[]");
    uiState.recentIds = Array.isArray(saved) ? saved : [];
  } catch {
    uiState.recentIds = [];
  }

  renderCategoryChips();
  renderFilterSelects();
  renderRecentChips();
  renderItems();
  bindEvents();
  pollStatus(true);
}

document.addEventListener("DOMContentLoaded", init);
